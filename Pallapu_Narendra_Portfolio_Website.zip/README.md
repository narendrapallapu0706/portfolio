# Pallapu Narendra Portfolio

## Publish with GitHub Pages

1. Create a GitHub repository named `portfolio` in the account `narendrapallapu0706`.
2. Upload `index.html` and `style.css` to the repository.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then click **Save**.
6. After GitHub publishes the site, your portfolio link will be:
   `https://narendrapallapu0706.github.io/portfolio/`

The site is already mobile-friendly and uses the information from your resume.
